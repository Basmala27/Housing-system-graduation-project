import os
from dotenv import load_dotenv

# Look for .env in backend folder first, then parent folder
_base = os.path.dirname(__file__)
load_dotenv(os.path.join(_base, ".env"))
load_dotenv(os.path.join(_base, "..", ".env"))
load_dotenv(os.path.join(_base, "..", "env"))  # also try without dot

# Groq API
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = "llama-3.3-70b-versatile"  # Best Arabic support, free tier

# Embeddings
EMBEDDING_MODEL = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"

# ChromaDB
CHROMA_DB_PATH = os.path.join(os.path.dirname(__file__), "../chroma_db")
CHROMA_COLLECTION_NAME = "real_estate_arabic"

# Data
UPLOADS_DIR = os.path.join(os.path.dirname(__file__), "../data/uploads")
CHUNK_SIZE = 500       # characters per chunk
CHUNK_OVERLAP = 50     # overlap between chunks

# RAG
TOP_K_RESULTS = 5      # number of chunks to retrieve
MAX_CHAT_HISTORY = 10  # number of messages to keep in memory