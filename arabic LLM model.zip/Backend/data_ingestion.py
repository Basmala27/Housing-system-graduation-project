import os
import pandas as pd
from config import UPLOADS_DIR, CHUNK_SIZE, CHUNK_OVERLAP


def load_csv_files(directory: str = UPLOADS_DIR) -> list[dict]:
    """Load all CSV files from the uploads directory."""
    all_records = []

    csv_files = [f for f in os.listdir(directory) if f.endswith(".csv")]
    if not csv_files:
        print("No CSV files found in uploads directory.")
        return []

    for filename in csv_files:
        filepath = os.path.join(directory, filename)
        try:
            df = pd.read_csv(filepath, encoding="utf-8")
            print(f"Loaded {filename}: {len(df)} rows, {len(df.columns)} columns")

            for idx, row in df.iterrows():
                # Convert each row to a text representation
                text = row_to_text(row, filename)
                all_records.append({
                    "text": text,
                    "source": filename,
                    "row_index": idx
                })

        except Exception as e:
            print(f"Error loading {filename}: {e}")

    print(f"Total records loaded: {len(all_records)}")
    return all_records


def row_to_text(row: pd.Series, source: str) -> str:
    """Convert a DataFrame row into a readable text string."""
    parts = []
    for col, val in row.items():
        if pd.notna(val) and str(val).strip():
            parts.append(f"{col}: {val}")
    return " | ".join(parts)


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split long text into overlapping chunks."""
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start += chunk_size - overlap

    return chunks


def prepare_documents(directory: str = UPLOADS_DIR) -> list[dict]:
    """
    Full pipeline: load CSVs → convert rows to text → chunk.
    Returns a list of document dicts ready for embedding.
    """
    records = load_csv_files(directory)
    documents = []

    for record in records:
        chunks = chunk_text(record["text"])
        for i, chunk in enumerate(chunks):
            documents.append({
                "text": chunk,
                "source": record["source"],
                "row_index": record["row_index"],
                "chunk_index": i
            })

    print(f"Total chunks prepared: {len(documents)}")
    return documents


if __name__ == "__main__":
    docs = prepare_documents()
    if docs:
        print("\nSample chunk:")
        print(docs[0]["text"])
