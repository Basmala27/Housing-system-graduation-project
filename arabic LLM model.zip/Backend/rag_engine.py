"""
rag.py — Smart Arabic Real-Estate Chatbot Backend
══════════════════════════════════════════════════
Two-layer architecture:
  Layer 1 → Pandas Router  : structured / aggregation questions
                             answered directly from CSV (fast, always correct)
  Layer 2 → ChromaDB+Groq  : descriptive / open-ended questions
                             using source-diverse vector retrieval

Tuned for your exact 3 CSVs:
  • North_coast.csv  → العلمين / الساحل الشمالي
  • L_Obour.csv      → العبور
  • new_cairo.csv    → نزهة الأندلس (مدخل أ / ب)
"""

import os
import re
import pandas as pd
from dotenv import load_dotenv
load_dotenv()

from groq import Groq
from config import GROQ_API_KEY, GROQ_MODEL, TOP_K_RESULTS, MAX_CHAT_HISTORY
from chroma_store import query_documents

if not GROQ_API_KEY:
    raise ValueError("No Groq API key found.")

client = Groq(api_key=GROQ_API_KEY)
chat_histories: dict[str, list] = {}

SYSTEM_PROMPT = """أنت مساعد عقاري ذكي متخصص في السوق العقاري المصري.

قواعد صارمة يجب اتباعها دائماً:
1. أجب فقط باللغة العربية الفصحى — ممنوع تماماً استخدام أي لغة أخرى (إنجليزية، صينية، فرنسية، إلخ)
2. إذا سأل المستخدم عن وحدة رقم محدد → اعرض بيانات تلك الوحدة فقط، لا تضف وحدات أخرى
3. إذا سأل عن مشروع محدد → اعرض بيانات ذلك المشروع فقط
4. لا تخترع أو تضيف معلومات غير موجودة في السياق المقدم
5. إذا لم تجد المعلومة في السياق، قل: "لا تتوفر هذه المعلومات في قاعدة البيانات"
6. كن دقيقاً ومختصراً — لا تكرر نفس المعلومة
7. استخدم الأرقام بالتنسيق العربي مع الفواصل (مثال: 876,700 جنيه)
"""

# ══════════════════════════════════════════════════════════════════════════════
# CSV LOADER  — normalizes all 3 CSV schemas into one unified DataFrame
# ══════════════════════════════════════════════════════════════════════════════

_BASE      = os.path.dirname(__file__)
CSV_FOLDER = os.path.join(_BASE, "..", "data", "uploads")

_combined_df: pd.DataFrame | None = None

def _load_all_csvs() -> pd.DataFrame | None:
    """
    Load all CSVs once, create unified __project__ and __floor__ columns
    so project-detection works across all files regardless of column names.
    """
    global _combined_df
    if _combined_df is not None:
        return _combined_df

    folder = os.path.abspath(CSV_FOLDER)
    if not os.path.isdir(folder):
        return None

    dfs = []
    for fname in sorted(os.listdir(folder)):
        if not fname.lower().endswith(".csv"):
            continue
        try:
            df = pd.read_csv(os.path.join(folder, fname), encoding="utf-8-sig")
            df.columns = df.columns.str.strip()
            df["__file__"] = fname

            # ── Normalize project column → __project__ ────────────────────
            proj_col = next((c for c in df.columns if "منطقة" in c or "مشروع" in c), None)
            df["__project__"] = df[proj_col].astype(str).str.strip() if proj_col else ""

            # ── Normalize floor column → __floor__ ───────────────────────
            floor_col = next((c for c in df.columns if "دور" in c or "طابق" in c), None)
            df["__floor__"] = df[floor_col].astype(str).str.strip() if floor_col else ""

            # ── Normalize price column → __price__ ───────────────────────
            price_col = next((c for c in df.columns
                              if "قيمة الوحدة" in c or "إجمالي سعر" in c), None)
            df["__price__"] = pd.to_numeric(df[price_col], errors="coerce") if price_col else None

            dfs.append(df)
        except Exception as e:
            print(f"[pandas] Could not load {fname}: {e}")

    if not dfs:
        return None

    _combined_df = pd.concat(dfs, ignore_index=True)
    return _combined_df


# ══════════════════════════════════════════════════════════════════════════════
# COLUMN RESOLVER — handles different column names across the 3 CSVs
# ══════════════════════════════════════════════════════════════════════════════

def _col(df: pd.DataFrame, *hints: str) -> str | None:
    """First column whose name contains any of the hint strings."""
    for hint in hints:
        for c in df.columns:
            if hint in c:
                return c
    return None


# ══════════════════════════════════════════════════════════════════════════════
# PROJECT DETECTOR — uses normalized __project__ column
# ══════════════════════════════════════════════════════════════════════════════

PROJECT_ALIASES: dict[str, list[str]] = {
    "العلمين":       ["العلمين", "ساحل", "الساحل", "الشمالي", "الساحل الشمالي", "علمين"],
    "العبور":        ["العبور", "عبور", "الابور", "obour"],
    "نزهة الأندلس": ["الأندلس", "اندلس", "أندلس", "نزهة", "القاهرة الجديدة", "cairo",
                      "مدخل أ", "مدخل ب"],
}

def _detect_project(question: str, df: pd.DataFrame) -> tuple[str | None, pd.DataFrame]:
    """Returns (label, subset_df). label is None if no project mentioned."""
    for label, aliases in PROJECT_ALIASES.items():
        if any(alias in question for alias in aliases):
            subset = df[df["__project__"].str.contains(label, na=False)]
            if len(subset) > 0:
                return label, subset
    return None, df


# ══════════════════════════════════════════════════════════════════════════════
# NUMBER FORMATTER
# ══════════════════════════════════════════════════════════════════════════════

def _fmt(n) -> str:
    try:   return f"{int(round(float(n))):,}"
    except: return str(n)


# ══════════════════════════════════════════════════════════════════════════════
# INTENT HANDLERS
# All share signature: (df_full, df_subset, question, project_label) -> str|None
# ══════════════════════════════════════════════════════════════════════════════

def _handle_projects(df, sub, q, proj):
    projects = df["__project__"].dropna().unique().tolist()
    names = "\n".join(f"  • {p}" for p in projects)
    return f"المشاريع المتاحة في قاعدة البيانات:\n{names}"


def _handle_project_summary(df, sub, q, proj):
    """Full summary card for a specific project when user asks about it by name."""
    if not proj:
        return None

    area_col  = _col(sub, "مساحة")
    elev_col  = _col(sub, "مصعد")
    bk_col    = _col(sub, "جدية")
    meter_col = _col(sub, "سعر المتر")
    inst3_col = _col(sub, "علي 3", "على 3", "لمدة (3)", "ربع سنوية")
    inst5_col = _col(sub, "علي 5", "على 5")
    inst7_col = _col(sub, "علي 7", "على 7")
    col_10    = _col(sub, "10%", "10% تسدد")
    col_20    = _col(sub, "20%", "استكمال", "قيمة استكمال", "%20 عند")

    floors   = sub["__floor__"].replace("nan", pd.NA).dropna().unique().tolist()
    floors   = [f for f in floors if f and f != "nan"]
    has_elev = None
    if elev_col:
        vals = sub[elev_col].dropna().unique()
        has_elev = "✓ يوجد" if any("مصعد" in str(v) for v in vals) else "✗ لا يوجد"

    lines = [f"🏢 ملخص مشروع {proj}", f"{'─'*40}"]
    lines.append(f"  • إجمالي الوحدات:        {len(sub):,} وحدة")
    lines.append(f"  • الأدوار ({len(floors)}):            {'، '.join(floors)}")

    if area_col:
        lines.append(f"  • المساحات:              {sub[area_col].min()}–{sub[area_col].max()} م²")
    if has_elev:
        lines.append(f"  • مصعد:                  {has_elev}")
    if meter_col:
        m = sub[meter_col].dropna().unique()
        if len(m) == 1:
            lines.append(f"  • سعر المتر:             {_fmt(m[0])} جنيه/م²")

    if sub["__price__"].notna().any():
        p = sub["__price__"].dropna()
        lines.append(f"  • أقل سعر وحدة:          {_fmt(p.min())} جنيه")
        lines.append(f"  • أعلى سعر وحدة:         {_fmt(p.max())} جنيه")
        lines.append(f"  • متوسط السعر:            {_fmt(p.mean())} جنيه")

    if bk_col:
        fees = sub[bk_col].dropna().unique()
        lines.append(f"  • جدية الحجز:             {_fmt(fees[0])} جنيه")
    if col_20:
        p20 = sub[col_20].dropna()
        if len(p20) > 0 and p20.notna().any():
            lines.append(f"  • استكمال 20%+رسوم:      {_fmt(p20.min())} – {_fmt(p20.max())} جنيه")
    if col_10:
        p10 = sub[col_10].dropna()
        if len(p10) > 0 and p10.notna().any():
            lines.append(f"  • دفعة 10% عند الاستلام: {_fmt(p10.min())} – {_fmt(p10.max())} جنيه")

    # Only show installment section if at least one option exists
    install_lines = []
    for y, c in [(3, inst3_col), (5, inst5_col), (7, inst7_col)]:
        if c:
            p = sub[c].dropna()
            if len(p) > 0 and p.notna().any():
                install_lines.append(f"  • {y} سنوات: {_fmt(p.min())} – {_fmt(p.max())} جنيه/شهر")

    if install_lines:
        lines.append(f"  {'─'*35}")
        lines.append("  خيارات التقسيط الشهري:")
        lines.extend(install_lines)

    lines.append("\n  💬 هل تريد تفاصيل وحدة معينة، أسعار، أقساط، أو أي معلومة أخرى؟")
    return "\n".join(lines)


def _handle_floors(df, sub, q, proj):
    floors = sub["__floor__"].replace("nan", pd.NA).dropna().unique().tolist()
    floors = [f for f in floors if f and f != "nan"]
    scope  = f"مشروع {proj}" if proj else "جميع المشاريع"
    return f"الأدوار المتاحة في {scope} ({len(floors)} أدوار):\n  {'، '.join(floors)}"


def _handle_floor_filter(df, sub, q, proj):
    """Show info about units on a specific floor."""
    FLOOR_MAP = {
        "الأرضي":           ["الأرضي","ارضي","أرضي","ground"],
        "الأول":            ["الأول","أول","اول","first"],
        "الثاني":           ["الثاني","ثاني","second"],
        "الثالث":           ["الثالث","ثالث","third"],
        "الرابع":           ["الرابع","رابع","fourth"],
        "الخامس":           ["الخامس","خامس","fifth"],
        "السادس":           ["السادس","سادس","sixth"],
        "الأخير":           ["الأخير","اخير","أخير","last","أعلى"],
        "الخامس والأخير":   ["خامس والأخير","خامس وأخير","خامس الأخير"],
    }
    for floor_name, aliases in FLOOR_MAP.items():
        if any(a in q for a in aliases):
            matched = sub[sub["__floor__"].str.contains(floor_name.split()[0], na=False)]
            if len(matched) == 0:
                return f"لا توجد وحدات في الدور {floor_name} ضمن النطاق المحدد."
            scope = f"مشروع {proj}" if proj else "جميع المشاريع"
            lines = [f"الوحدات في الدور {floor_name} ({scope}) — {len(matched)} وحدة:"]
            if matched["__price__"].notna().any():
                lines.append(f"  • السعر: {_fmt(matched['__price__'].min())} – {_fmt(matched['__price__'].max())} جنيه")
            area_col = _col(matched, "مساحة")
            if area_col:
                lines.append(f"  • المساحة: {matched[area_col].min()} – {matched[area_col].max()} م²")
            return "\n".join(lines)
    return None


def _handle_unit_count(df, sub, q, proj):
    if proj:
        return f"عدد الوحدات في مشروع {proj}: **{len(sub):,} وحدة**"
    counts = df.groupby("__project__").size()
    lines  = "\n".join(f"  • {str(k).strip()}: {v:,} وحدة" for k, v in counts.items())
    return f"إجمالي الوحدات: **{len(df):,} وحدة**\n{lines}"


def _handle_area(df, sub, q, proj):
    area_col = _col(sub, "مساحة")
    if not area_col:
        return None
    scope = f"مشروع {proj}" if proj else "جميع المشاريع"

    nums = [int(n) for n in re.findall(r'\d+', q) if 50 <= int(n) <= 500]
    if nums:
        target  = nums[0]
        matches = sub[abs(sub[area_col] - target) <= 5]
        if len(matches) > 0:
            price_str = (f" — سعر الوحدة: **{_fmt(matches['__price__'].iloc[0])}** جنيه"
                         if matches["__price__"].notna().any() else "")
            return (f"يوجد {len(matches)} وحدة بمساحة ≈{target} م² في {scope}{price_str}\n"
                    f"  المساحات الفعلية: {', '.join(str(x) for x in sorted(matches[area_col].unique()))}")

    vals    = sorted(sub[area_col].dropna().unique().tolist())
    vals_str = "، ".join(str(v) for v in vals)
    return (f"المساحات المتاحة في {scope}:\n"
            f"  • أصغر مساحة: **{sub[area_col].min()} م²**\n"
            f"  • أكبر مساحة: **{sub[area_col].max()} م²**\n"
            f"  • جميع المساحات: {vals_str}")


def _handle_price(df, sub, q, proj):
    scope = f"مشروع {proj}" if proj else "جميع المشاريع"
    lines = [f"الأسعار في {scope}:"]

    if sub["__price__"].notna().any():
        p = sub["__price__"].dropna()
        lines += [f"  • أقل سعر وحدة:   **{_fmt(p.min())}** جنيه",
                  f"  • أعلى سعر وحدة:  **{_fmt(p.max())}** جنيه",
                  f"  • متوسط السعر:     **{_fmt(p.mean())}** جنيه"]

    meter_col = _col(sub, "سعر المتر")
    if meter_col:
        vals = sub[meter_col].dropna().unique()
        if len(vals) == 1:
            lines.append(f"  • سعر المتر: **{_fmt(vals[0])}** جنيه/م²")
        else:
            lines.append(f"  • سعر المتر: {_fmt(vals.min())} – {_fmt(vals.max())} جنيه/م²")

    return "\n".join(lines) if len(lines) > 1 else None


def _handle_booking_fee(df, sub, q, proj):
    col   = _col(sub, "جدية")
    scope = f"مشروع {proj}" if proj else "جميع المشاريع"
    if not col:
        return None
    fees = sub[col].dropna().unique()
    if len(fees) == 1:
        return f"جدية الحجز في {scope}: **{_fmt(fees[0])}** جنيه"
    return f"جديات الحجز في {scope}: {' / '.join(_fmt(f) for f in fees)} جنيه"


def _handle_installments(df, sub, q, proj):
    scope = f"مشروع {proj}" if proj else "جميع المشاريع"
    asked = []
    if any(x in q for x in ["3","ثلاث","ثلاثة"]): asked.append(3)
    if any(x in q for x in ["5","خمس","خمسة"]):   asked.append(5)
    if any(x in q for x in ["7","سبع","سبعة"]):    asked.append(7)
    if not asked: asked = [3, 5, 7]

    lines = [f"خيارات التقسيط في {scope}:"]
    for y in asked:
        col = _col(sub, f"علي {y}", f"على {y}", f"لمدة ({y})")
        if col:
            p = sub[col].dropna()
            if len(p) == 0: continue
            if p.min() == p.max():
                lines.append(f"  • قسط {y} سنوات: **{_fmt(p.min())}** جنيه/شهر")
            else:
                lines.append(f"  • قسط {y} سنوات: {_fmt(p.min())} – {_fmt(p.max())} جنيه/شهر")

    return "\n".join(lines) if len(lines) > 1 else None


def _handle_down_payment(df, sub, q, proj):
    scope = f"مشروع {proj}" if proj else "جميع المشاريع"
    lines = [f"الدفعات المقدمة في {scope}:"]

    col_bk  = _col(sub, "جدية")
    col_10  = _col(sub, "10%")
    col_20  = _col(sub, "20%", "استكمال")

    if col_bk:
        fees = sub[col_bk].dropna().unique()
        val  = _fmt(fees[0]) if len(fees)==1 else " / ".join(_fmt(f) for f in fees)
        lines.append(f"  • جدية الحجز:        **{val}** جنيه")
    if col_10:
        p = sub[col_10].dropna()
        lines.append(f"  • دفعة 10%:          {_fmt(p.min())} – {_fmt(p.max())} جنيه" if p.min()!=p.max()
                     else f"  • دفعة 10%:          **{_fmt(p.min())}** جنيه")
    if col_20:
        p = sub[col_20].dropna()
        lines.append(f"  • دفعة 20% / استكمال: {_fmt(p.min())} – {_fmt(p.max())} جنيه" if p.min()!=p.max()
                     else f"  • دفعة 20% / استكمال: **{_fmt(p.min())}** جنيه")

    return "\n".join(lines) if len(lines) > 1 else None


def _handle_elevator(df, sub, q, proj):
    col   = _col(sub, "مصعد")
    scope = f"مشروع {proj}" if proj else "جميع المشاريع"
    if not col:
        return f"لا تتوفر معلومات عن المصعد في {scope}"
    vals = sub[col].dropna().unique().tolist()
    if len(vals) == 1:
        has = "✓ يوجد مصعد" if "مصعد" in str(vals[0]) else "✗ لا يوجد مصعد"
        return f"{has} في {scope}"
    return f"حالة المصعد في {scope}: {' / '.join(str(v) for v in vals)}"


def _handle_unit_lookup(df, sub, q, proj):
    nums = re.findall(r'\b\d+\b', q)
    # Filter out numbers that are clearly not unit numbers (e.g. years like 3,5,7)
    nums = [n for n in nums if int(n) > 0 and int(n) not in (3, 5, 7, 10, 20)]
    if not nums: return None
    num_col = _col(sub, "رقم الوحدة", "رقم")
    if not num_col: return None

    for num in nums:
        # Exact match only — no partial matches
        matches = sub[sub[num_col].astype(str).str.strip() == str(int(num))]
        if len(matches) == 0:
            # Try with the full df if subset gave nothing
            matches = df[df[num_col].astype(str).str.strip() == str(int(num))]
        if len(matches) > 0:
            row = matches.iloc[0]   # Always take exactly ONE row
            lines = [f"📋 تفاصيل الوحدة رقم {num}:"]
            lines.append(f"  • المشروع:              {row['__project__']}")
            lines.append(f"  • الدور:                {row['__floor__']}")
            area_col  = _col(matches, "مساحة")
            elev_col  = _col(matches, "مصعد")
            meter_col = _col(matches, "سعر المتر")
            inst3_col = _col(matches, "علي 3", "على 3", "لمدة (3)")
            inst5_col = _col(matches, "علي 5", "على 5")
            inst7_col = _col(matches, "علي 7", "على 7")
            bk_col    = _col(matches, "جدية")
            col_10    = _col(matches, "10%")
            col_20    = _col(matches, "20%", "استكمال")
            if area_col:   lines.append(f"  • المساحة:              {row[area_col]} م²")
            if elev_col:   lines.append(f"  • مصعد:                 {row[elev_col]}")
            if meter_col:  lines.append(f"  • سعر المتر:            {_fmt(row[meter_col])} جنيه/م²")
            if pd.notna(row["__price__"]):
                lines.append(f"  • قيمة الوحدة:          {_fmt(row['__price__'])} جنيه")
            if bk_col:     lines.append(f"  • جدية الحجز:          {_fmt(row[bk_col])} جنيه")
            if col_20:     lines.append(f"  • استكمال 20%+رسوم:    {_fmt(row[col_20])} جنيه")
            if col_10:     lines.append(f"  • قيمة 10% عند الاستلام: {_fmt(row[col_10])} جنيه")
            lines.append(f"  {'─'*35}")
            lines.append(f"  خيارات التقسيط الشهري:")
            if inst3_col:  lines.append(f"  • 3 سنوات: {_fmt(row[inst3_col])} جنيه/شهر")
            if inst5_col:  lines.append(f"  • 5 سنوات: {_fmt(row[inst5_col])} جنيه/شهر")
            if inst7_col:  lines.append(f"  • 7 سنوات: {_fmt(row[inst7_col])} جنيه/شهر")
            return "\n".join(lines)

    return f"لم يتم العثور على وحدة برقم {nums[0]} في قاعدة البيانات."


def _handle_compare(df, sub, q, proj):
    lines = ["📊 مقارنة جميع المشاريع:\n"]
    for p_name, group in df.groupby("__project__"):
        area_col = _col(group, "مساحة")
        elev_col = _col(group, "مصعد")
        bk_col   = _col(group, "جدية")
        inst7    = _col(group, "علي 7", "على 7")
        has_elev = "✓" if elev_col and "مصعد" in str(group[elev_col].iloc[0]) else "✗"
        floors   = group["__floor__"].replace("nan", pd.NA).dropna().unique().tolist()

        lines.append(f"🏢 {str(p_name).strip()}")
        lines.append(f"  • الوحدات:       {len(group):,}")
        lines.append(f"  • الأدوار:       {len(floors)} ({', '.join(floors)})")
        if area_col:
            lines.append(f"  • المساحة:       {group[area_col].min()}–{group[area_col].max()} م²")
        if group["__price__"].notna().any():
            p = group["__price__"].dropna()
            lines.append(f"  • السعر:         {_fmt(p.min())} – {_fmt(p.max())} جنيه")
        if bk_col:
            lines.append(f"  • جدية الحجز:    {_fmt(group[bk_col].iloc[0])} جنيه")
        if inst7:
            p7 = group[inst7].dropna()
            if len(p7) > 0:
                lines.append(f"  • قسط 7 سنوات:  {_fmt(p7.min())} – {_fmt(p7.max())} جنيه/شهر")
        lines.append(f"  • مصعد:          {has_elev}")
        lines.append("")
    return "\n".join(lines)


def _handle_cheapest(df, sub, q, proj):
    if sub["__price__"].isna().all(): return None
    top      = sub.dropna(subset=["__price__"]).nsmallest(5, "__price__")
    num_col  = _col(sub, "رقم الوحدة")
    area_col = _col(sub, "مساحة")
    lines    = ["💰 أرخص الوحدات المتاحة:"]
    for _, row in top.iterrows():
        parts = []
        if num_col:  parts.append(f"وحدة #{int(row[num_col]) if pd.notna(row[num_col]) else '?'}")
        parts.append(str(row["__project__"]).strip())
        parts.append(f"دور {row['__floor__']}")
        if area_col: parts.append(f"{row[area_col]} م²")
        parts.append(f"**{_fmt(row['__price__'])}** جنيه")
        lines.append("  • " + " | ".join(parts))
    return "\n".join(lines)


def _handle_most_expensive(df, sub, q, proj):
    if sub["__price__"].isna().all(): return None
    top      = sub.dropna(subset=["__price__"]).nlargest(5, "__price__")
    num_col  = _col(sub, "رقم الوحدة")
    area_col = _col(sub, "مساحة")
    lines    = ["💎 أعلى الوحدات سعراً:"]
    for _, row in top.iterrows():
        parts = []
        if num_col:  parts.append(f"وحدة #{int(row[num_col]) if pd.notna(row[num_col]) else '?'}")
        parts.append(str(row["__project__"]).strip())
        parts.append(f"دور {row['__floor__']}")
        if area_col: parts.append(f"{row[area_col]} م²")
        parts.append(f"**{_fmt(row['__price__'])}** جنيه")
        lines.append("  • " + " | ".join(parts))
    return "\n".join(lines)


def _handle_budget(df, sub, q, proj):
    nums = [int(n.replace(",","")) for n in re.findall(r'[\d,]+', q)
            if int(n.replace(",","")) > 50000]
    if not nums: return None
    budget  = max(nums)
    matched = sub[sub["__price__"] <= budget].dropna(subset=["__price__"])
    if len(matched) == 0:
        mn = sub["__price__"].dropna().min()
        return f"لا توجد وحدات بسعر أقل من {_fmt(budget)} جنيه.\nأقل سعر متاح: **{_fmt(mn)}** جنيه"

    num_col  = _col(matched, "رقم الوحدة")
    area_col = _col(matched, "مساحة")
    lines    = [f"الوحدات بسعر أقل من {_fmt(budget)} جنيه ({len(matched)} وحدة):"]
    for _, row in matched.head(6).iterrows():
        parts = []
        if num_col:  parts.append(f"وحدة #{int(row[num_col]) if pd.notna(row[num_col]) else '?'}")
        parts.append(str(row["__project__"]).strip())
        parts.append(f"دور {row['__floor__']}")
        if area_col: parts.append(f"{row[area_col]} م²")
        parts.append(f"{_fmt(row['__price__'])} جنيه")
        lines.append("  • " + " | ".join(parts))
    if len(matched) > 6:
        lines.append(f"  ... و{len(matched)-6} وحدة أخرى")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# INTENT ROUTING TABLE  (most-specific first, first match wins)
# ══════════════════════════════════════════════════════════════════════════════

INTENTS = [
    # Project summary — when user mentions a project name without a specific question
    (["العلمين","الساحل","العبور","الأندلس","اندلس","نزهة",
      "معلومات عن","أخبرني عن","عايز أعرف عن","ما هو مشروع"],             _handle_project_summary),
    (["قارن","مقارنة","الفرق بين","جميع المشاريع","كل المشاريع"],          _handle_compare),
    (["بميزانية","ميزانية","بحد أقصى","أقل من","لا يتجاوز","في حدود"],     _handle_budget),
    (["الوحدة رقم","وحدة رقم","رقم الوحدة"],                               _handle_unit_lookup),
    (["أرخص","أقل سعر","أوفر","أقل تكلفة","الأرخص"],                       _handle_cheapest),
    (["أغلى","أعلى سعر","أكثر سعرا","الأغلى"],                             _handle_most_expensive),
    (["الأرضي","الأول","الثاني","الثالث","الرابع","الخامس","السادس",
      "الأخير","ارضي","اول","ثاني","ثالث","رابع","خامس","سادس","اخير"],    _handle_floor_filter),
    (["قسط","أقساط","تقسيط","3 سنوات","5 سنوات","7 سنوات",
      "ثلاث سنوات","خمس سنوات","سبع سنوات"],                               _handle_installments),
    (["مقدم","دفعة","دفعات","10%","20%","استكمال","جدية","حجز"],            _handle_down_payment),
    (["مصعد","اسانسير","lift","elevator"],                                   _handle_elevator),
    (["سعر","أسعار","تكلفة","بكام","بكم","يساوي","كم سعر"],                _handle_price),
    (["مساحة","مساحات","م²","متر مربع"],                                    _handle_area),
    (["أدوار","الأدوار","ادوار","كم دور","طابق","طوابق","الدور"],           _handle_floors),
    (["كم وحدة","عدد الوحدات","كمية الوحدات","إجمالي الوحدات"],            _handle_unit_count),
    (["مشاريع","مناطق","اليس","هل يوجد","هل هناك","ما هي المشاريع",
      "ما المشاريع","مشروع آخر","مشاريع أخرى"],                            _handle_projects),
]

ALWAYS_STRUCTURED = [
    "كم","عدد","مجموع","إجمالي","متوسط","قارن","مقارنة",
    "أرخص","أغلى","قسط","مقدم","جدية","مصعد","بكام","بكم",
    "ميزانية","يساوي","سعر","مساحة","أدوار",
    # Project names — always handle via pandas to avoid LLM hallucination
    "العلمين","الساحل الشمالي","العبور","الأندلس","نزهة",
]

def _is_structured(question: str) -> bool:
    if any(kw in question for kw in ALWAYS_STRUCTURED):
        return True
    return any(any(t in question for t in triggers) for triggers, _ in INTENTS)


def _pandas_answer(question: str) -> str | None:
    df = _load_all_csvs()
    if df is None:
        return None

    proj_label, subset = _detect_project(question, df)

    for triggers, handler in INTENTS:
        if any(t in question for t in triggers):
            result = handler(df, subset, question, proj_label)
            if result:
                return result
    return None


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def build_context(retrieved_docs: list[dict]) -> str:
    if not retrieved_docs:
        return "لا توجد معلومات متاحة في قاعدة البيانات."
    return "\n\n".join(
        f"[{i}] المصدر: {doc['source']}\n{doc['text']}"
        for i, doc in enumerate(retrieved_docs, 1)
    )


# ══════════════════════════════════════════════════════════════════════════════
# MAIN CHAT
# ══════════════════════════════════════════════════════════════════════════════

def chat(query: str, session_id: str = "default") -> dict:
    if session_id not in chat_histories:
        chat_histories[session_id] = []

    # ── Layer 1: Pandas router ────────────────────────────────────────────────
    if _is_structured(query):
        result = _pandas_answer(query)
        if result:
            chat_histories[session_id].append({"role": "user",      "content": query})
            chat_histories[session_id].append({"role": "assistant", "content": result})
            return {"answer": result, "sources": ["قاعدة البيانات المباشرة"], "session_id": session_id}

    # ── Layer 2: ChromaDB + Groq ──────────────────────────────────────────────
    retrieved_docs = query_documents(query, top_k=TOP_K_RESULTS)
    context        = build_context(retrieved_docs)

    # Extra guard: prevent LLM from adding irrelevant units
    unit_nums = [n for n in re.findall(r"\b\d+\b", query) if int(n) not in (3,5,7,10,20)]
    unit_instruction = ""
    if unit_nums and any(kw in query for kw in ["وحدة رقم", "الوحدة رقم", "رقم الوحدة"]):
        unit_instruction = (
            f"\n\n⚠️ تعليم مهم: المستخدم يسأل عن الوحدة رقم {unit_nums[0]} فقط. "
            "اعرض بيانات هذه الوحدة فقط ولا تذكر أي وحدة أخرى."
        )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT + unit_instruction + f"\n\nالمعلومات العقارية المتاحة:\n{context}"},
    ]
    for msg in chat_histories[session_id][-MAX_CHAT_HISTORY * 2:]:
        messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": query})

    try:
        response = client.chat.completions.create(
            model=GROQ_MODEL, messages=messages, max_tokens=1024, temperature=0.7
        )
        answer = response.choices[0].message.content.strip()
    except Exception as e:
        answer = f"عذراً، حدث خطأ أثناء معالجة طلبك: {str(e)}"

    chat_histories[session_id].append({"role": "user",      "content": query})
    chat_histories[session_id].append({"role": "assistant", "content": answer})
    if len(chat_histories[session_id]) > MAX_CHAT_HISTORY * 2:
        chat_histories[session_id] = chat_histories[session_id][-MAX_CHAT_HISTORY * 2:]

    return {
        "answer": answer,
        "sources": [doc["source"] for doc in retrieved_docs],
        "session_id": session_id
    }


def clear_history(session_id: str = "default"):
    if session_id in chat_histories:
        chat_histories[session_id] = []