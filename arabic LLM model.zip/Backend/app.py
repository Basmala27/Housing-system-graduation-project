import os
import uuid
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

from config import UPLOADS_DIR
from data_ingestion import prepare_documents
from chroma_store import add_documents, clear_collection, get_collection_info
from rag_engine import chat, clear_history

app = Flask(__name__, static_folder="../Frontend")
CORS(app)

ALLOWED_EXTENSIONS = {"csv"}


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS



@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(app.static_folder, filename)


# ── Chat ──────────────────────────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.get_json()
    if not data or "message" not in data:
        return jsonify({"error": "Missing 'message' field"}), 400

    query = data["message"].strip()
    session_id = data.get("session_id", "default")

    if not query:
        return jsonify({"error": "Empty message"}), 400

    result = chat(query, session_id)
    return jsonify(result)


@app.route("/api/chat/clear", methods=["POST"])
def api_clear_history():
    data = request.get_json() or {}
    session_id = data.get("session_id", "default")
    clear_history(session_id)
    return jsonify({"message": "Chat history cleared", "session_id": session_id})


# ── CSV Upload & Ingestion ────────────────────────────────────────────────────

@app.route("/api/upload", methods=["POST"])
def api_upload():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Only CSV files are allowed"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOADS_DIR, filename)
    file.save(filepath)

    return jsonify({"message": f"File '{filename}' uploaded successfully", "filename": filename})


@app.route("/api/ingest", methods=["POST"])
def api_ingest():
    """Re-process all uploaded CSVs and load into ChromaDB."""
    try:
        documents = prepare_documents()
        if not documents:
            return jsonify({"error": "No documents found to ingest"}), 400

        add_documents(documents)
        info = get_collection_info()
        return jsonify({
            "message": "Ingestion complete",
            "chunks_ingested": len(documents),
            "total_in_db": info["count"]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/ingest/reset", methods=["POST"])
def api_reset_ingest():
    """Clear ChromaDB and re-ingest all CSVs from scratch."""
    try:
        clear_collection()
        documents = prepare_documents()
        if not documents:
            return jsonify({"error": "No documents found to ingest"}), 400

        add_documents(documents)
        info = get_collection_info()
        return jsonify({
            "message": "Reset and re-ingestion complete",
            "chunks_ingested": len(documents),
            "total_in_db": info["count"]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Status ────────────────────────────────────────────────────────────────────

@app.route("/api/status", methods=["GET"])
def api_status():
    info = get_collection_info()
    csv_files = [f for f in os.listdir(UPLOADS_DIR) if f.endswith(".csv")]
    return jsonify({
        "status": "running",
        "csv_files": csv_files,
        "db_chunks": info["count"]
    })


if __name__ == "__main__":
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    app.run(debug=True, port=5000)
