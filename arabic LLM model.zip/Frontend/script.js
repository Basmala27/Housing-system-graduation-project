const API = "http://localhost:5000/api";
const sessionId = "session_" + Math.random().toString(36).substr(2, 9);

// ── DOM Refs ───────────────────────────────────────────────────────────────
const chatWindow   = document.getElementById("chatWindow");
const userInput    = document.getElementById("userInput");
const sendBtn      = document.getElementById("sendBtn");
const fileInput    = document.getElementById("fileInput");
const uploadZone   = document.getElementById("uploadZone");
const uploadStatus = document.getElementById("uploadStatus");
const dbStatus     = document.getElementById("dbStatus");
const statusDot    = document.getElementById("statusDot");
const statusText   = document.getElementById("statusText");
const dbInfo       = document.getElementById("dbInfo");

// ── Toast ──────────────────────────────────────────────────────────────────
function showToast(message, type = "info", duration = 3000) {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), duration);
}

// ── Status Check ───────────────────────────────────────────────────────────
async function checkStatus() {
  try {
    const res = await fetch(`${API}/status`);
    const data = await res.json();
    statusDot.className = "status-dot online";
    statusText.textContent = "متصل";
    dbInfo.innerHTML = `
      <div>الملفات: ${data.csv_files.length > 0 ? data.csv_files.join(", ") : "لا يوجد"}</div>
      <div>أجزاء البيانات: ${data.db_chunks}</div>
    `;
  } catch {
    statusDot.className = "status-dot offline";
    statusText.textContent = "غير متصل - تأكد من تشغيل Flask";
    dbInfo.innerHTML = "";
  }
}

// ── Chat ───────────────────────────────────────────────────────────────────
function addMessage(role, content, sources = []) {
  const wrap = document.createElement("div");
  wrap.className = `message ${role === "user" ? "user-message" : "assistant-message"}`;

  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "👤" : "🏛";

  const msgContent = document.createElement("div");
  msgContent.className = "message-content";

  // Convert newlines to paragraphs
  const paragraphs = content.split("\n").filter(p => p.trim());
  paragraphs.forEach(p => {
    const para = document.createElement("p");
    para.textContent = p;
    msgContent.appendChild(para);
  });

  // Add sources
  if (sources.length > 0) {
    const srcDiv = document.createElement("div");
    srcDiv.className = "message-sources";
    srcDiv.innerHTML = "<span>المصادر:</span> " +
      [...new Set(sources)].map(s => `<span class="source-badge">${s}</span>`).join("");
    msgContent.appendChild(srcDiv);
  }

  wrap.appendChild(avatar);
  wrap.appendChild(msgContent);
  chatWindow.appendChild(wrap);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return wrap;
}

function addTypingIndicator() {
  const wrap = document.createElement("div");
  wrap.className = "message assistant-message typing-indicator";
  wrap.innerHTML = `
    <div class="message-avatar">🏛</div>
    <div class="message-content">
      <div class="typing-dots">
        <span></span><span></span><span></span>
      </div>
    </div>`;
  chatWindow.appendChild(wrap);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return wrap;
}

async function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  userInput.value = "";
  userInput.style.height = "auto";
  sendBtn.disabled = true;

  addMessage("user", message);
  const typing = addTypingIndicator();

  try {
    const res = await fetch(`${API}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, session_id: sessionId })
    });
    const data = await res.json();
    typing.remove();

    if (data.error) {
      addMessage("assistant", `❌ خطأ: ${data.error}`);
    } else {
      addMessage("assistant", data.answer, data.sources || []);
    }
  } catch (err) {
    typing.remove();
    addMessage("assistant", "❌ تعذر الاتصال بالخادم. تأكد من تشغيل Flask على المنفذ 5000.");
  } finally {
    sendBtn.disabled = false;
    userInput.focus();
  }
}

async function clearChat() {
  try {
    await fetch(`${API}/chat/clear`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId })
    });
  } catch {}

  // Clear all messages except welcome
  const messages = chatWindow.querySelectorAll(".message:not(.welcome-message)");
  messages.forEach(m => m.remove());
  showToast("تم مسح المحادثة", "info");
}

// ── Input Handling ─────────────────────────────────────────────────────────
function handleKeyDown(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

function autoResize(el) {
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 120) + "px";
}

// ── File Upload ────────────────────────────────────────────────────────────
uploadZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  uploadZone.classList.add("drag-over");
});

uploadZone.addEventListener("dragleave", () => {
  uploadZone.classList.remove("drag-over");
});

uploadZone.addEventListener("drop", (e) => {
  e.preventDefault();
  uploadZone.classList.remove("drag-over");
  const files = [...e.dataTransfer.files].filter(f => f.name.endsWith(".csv"));
  if (files.length > 0) uploadFiles(files);
});

fileInput.addEventListener("change", () => {
  if (fileInput.files.length > 0) uploadFiles([...fileInput.files]);
});

async function uploadFiles(files) {
  uploadStatus.innerHTML = "";

  for (const file of files) {
    const item = document.createElement("div");
    item.className = "upload-item";
    item.textContent = `⏳ ${file.name}`;
    uploadStatus.appendChild(item);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch(`${API}/upload`, { method: "POST", body: formData });
      const data = await res.json();
      if (res.ok) {
        item.className = "upload-item success";
        item.textContent = `✅ ${file.name}`;
      } else {
        item.className = "upload-item error";
        item.textContent = `❌ ${file.name}: ${data.error}`;
      }
    } catch {
      item.className = "upload-item error";
      item.textContent = `❌ ${file.name}: فشل الرفع`;
    }
  }

  await checkStatus();
  showToast("تم رفع الملفات. اضغط 'معالجة البيانات'", "info", 4000);
}

// ── Ingestion ──────────────────────────────────────────────────────────────
async function ingestData() {
  showToast("جاري معالجة البيانات...", "info", 8000);
  try {
    const res = await fetch(`${API}/ingest`, { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      showToast(`✅ تمت المعالجة: ${data.chunks_ingested} جزء`, "success", 4000);
      await checkStatus();
    } else {
      showToast(`❌ خطأ: ${data.error}`, "error", 5000);
    }
  } catch {
    showToast("❌ تعذر الاتصال بالخادم", "error");
  }
}

async function resetAndIngest() {
  if (!confirm("سيتم حذف قاعدة البيانات وإعادة المعالجة. هل أنت متأكد؟")) return;
  showToast("جاري إعادة المعالجة...", "info", 10000);
  try {
    const res = await fetch(`${API}/ingest/reset`, { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      showToast(`✅ تمت إعادة المعالجة: ${data.chunks_ingested} جزء`, "success", 4000);
      await checkStatus();
    } else {
      showToast(`❌ خطأ: ${data.error}`, "error", 5000);
    }
  } catch {
    showToast("❌ تعذر الاتصال بالخادم", "error");
  }
}

// ── Sidebar Toggle (mobile) ────────────────────────────────────────────────
function toggleSidebar() {
  document.querySelector(".sidebar").classList.toggle("open");
}

// ── Init ───────────────────────────────────────────────────────────────────
checkStatus();
setInterval(checkStatus, 30000);
userInput.focus();
